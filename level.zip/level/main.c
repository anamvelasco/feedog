#include <stdio.h>
#include "pico/stdlib.h"
#include "hardware/adc.h"

#define WATER_SENSOR_PIN 26  // ADC0 is GP26

void init_adc() {
    adc_init();
    adc_gpio_init(WATER_SENSOR_PIN);
    adc_select_input(0);  // ADC input 0 is connected to GP26
}

uint16_t read_water_level() {
    return adc_read();
}

int main() {
    stdio_init_all();
    init_adc();

    while (true) {
        uint16_t water_level = read_water_level();
        printf("Water Level: %d\n", water_level);
        sleep_ms(1000);  // Delay 1 second
    }

    return 0;
}
