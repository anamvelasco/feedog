#include "pico/stdlib.h"

#define PUMP_PIN 28

int main() {
    // Initialize the GPIO for the pump
    gpio_init(PUMP_PIN);
    gpio_set_dir(PUMP_PIN, GPIO_OUT);

    while (true) {
        // Turn on the pump
        gpio_put(PUMP_PIN, 1);
        // Wait for 2 seconds
        sleep_ms(2000);

        // Turn off the pump
        gpio_put(PUMP_PIN, 0);
        // Wait for 3 seconds
        sleep_ms(3000);
    }

    return 0;
}
