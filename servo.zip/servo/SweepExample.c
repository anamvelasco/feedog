#include "servo.h"
#include <stdio.h>
#include "pico/stdlib.h"
#include "hardware/pwm.h"
#include "hardware/clocks.h"

// Constants for servo control
const int servoPin = 0;
const float minPulseWidth = 1.0f;   // Pulse width for 0 degrees (in ms)
const float maxPulseWidth = 2.0f;   // Pulse width for 180 degrees (in ms)

// Function to convert degrees to pulse width in milliseconds
float degreesToMillis(float degrees)
{
    return minPulseWidth + (degrees / 180.0f) * (maxPulseWidth - minPulseWidth);
}

float clockDiv = 64.0f;
float wrap = 39062.0f;

void setMillis(int servoPin, float millis)
{
    pwm_set_gpio_level(servoPin, (millis / 20.0f) * wrap);  // 20 ms period
}

void setServo(int servoPin, float startMillis)
{
    gpio_set_function(servoPin, GPIO_FUNC_PWM);
    uint slice_num = pwm_gpio_to_slice_num(servoPin);

    pwm_config config = pwm_get_default_config();

    uint64_t clockspeed = clock_get_hz(clk_sys);
    clockDiv = 64.0f;
    wrap = 39062.0f;

    while (clockspeed / clockDiv / 50 > 65535 && clockDiv < 256) 
        clockDiv += 64; 
    
    wrap = clockspeed / clockDiv / 50;

    pwm_config_set_clkdiv(&config, clockDiv);
    pwm_config_set_wrap(&config, wrap);

    pwm_init(slice_num, &config, true);

    setMillis(servoPin, startMillis);
}

int main()
{
    // Define the initial and final positions in degrees
    const float initialPositionDegrees = 25.0f;  // Initial position (0 degrees)
    const float finalPositionDegrees = 90.0f;   // Final position (45 degrees)

    // Convert degrees to pulse widths
    float initialPositionMillis = degreesToMillis(initialPositionDegrees);
    float finalPositionMillis = degreesToMillis(finalPositionDegrees);

    // Initialize the servo to the initial position
    setServo(servoPin, initialPositionMillis);

    while (true)
    {
        // Keep the servo in the initial position for 10 seconds
        setMillis(servoPin, initialPositionMillis);
        sleep_ms(10000); // 10 seconds

        // Move the servo to the final position
        setMillis(servoPin, finalPositionMillis);
        sleep_ms(500); // 0.5 seconds

        // Move the servo back to the initial position
        setMillis(servoPin, initialPositionMillis);
    }
}
